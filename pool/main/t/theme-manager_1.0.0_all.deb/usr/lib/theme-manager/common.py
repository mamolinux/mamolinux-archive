#!/usr/bin/python3

# Copyright (C) 2021 Himadri Sekhar Basu <hsb10@iitbbs.ac.in>
#
# This file is part of theme-manager.
#
# theme-manager is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# theme-manager is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with theme-manager. If not, see <http://www.gnu.org/licenses/>
# or write to the Free Software Foundation, Inc., 51 Franklin Street,
# Fifth Floor, Boston, MA 02110-1301, USA..
#
# Author: Himadri Sekhar Basu <hsb10@iitbbs.ac.in>
#

# import the necessary modules!
import ast
import configparser
import datetime
import gettext
import locale
import os
import random
import threading
from gi.repository import GObject
from threading import Thread


# Used as a decorator to run things in the background
def _async(func):
	def wrapper(*args, **kwargs):
		thread = threading.Thread(target=func, args=args, kwargs=kwargs)
		thread.daemon = True
		thread.start()
		return thread
	return wrapper

# Used as a decorator to run things in the main loop, from another thread
def idle(func):
	def wrapper(*args):
		GObject.idle_add(func, *args)
	return wrapper

# i18n
APP = 'theme-manager'
LOCALE_DIR = "/usr/share/locale"
locale.bindtextdomain(APP, LOCALE_DIR)
gettext.bindtextdomain(APP, LOCALE_DIR)
gettext.textdomain(APP)
_ = gettext.gettext

# Constants
LOG_FILE="/tmp/change-theme.log"
CONFIG_DIR = os.path.expanduser('~/.config/theme-manager/')
CONFIG_FILE = os.path.join(CONFIG_DIR+'config.cfg')


# This is the backend.
# It contains utility functions to manage
# themes
class ThemeManager():
	
	def __init__(self):

		# run the daemon
		self.daemon = Thread(target=self.__run_daemon)
		self.daemon.setDaemon(True)
		self.daemon.start()
		
		self.TrueRand = random.SystemRandom()
		
		if os.path.exists(CONFIG_DIR):
			pass
		else:
			os.makedirs(CONFIG_DIR)
		
		self.config = configparser.ConfigParser()
		self.save_config()
		
	def load_config(self):
		"""Loads configurations from config file.
		
		Tries to read and parse from config file.
		If the config file is missing or not readable,
		then it triggers default configurations.
		"""
		
		self.config.read(CONFIG_FILE)
		try:
			colvars = self.config["system-theme"]['color-variants'].split(' ')
			self.colvariants=ast.literal_eval(self.config["system-theme"]['color-variants'])
			self.systemthemename = self.config["system-theme"]['system-theme-name']
			self.iconthemename = self.config["system-theme"]['icon-theme-name']
			self.cursorthemename = self.config["system-theme"]['cursor-theme-name']
			
			self.colorvariants = ""
			for var in colvars:
				self.colorvariants += str(var+" ")
			self.colorvariants = self.colorvariants.strip()
		except:
			pass
	
	def save_config(self):
		if os.path.exists(CONFIG_FILE):
			pass
		else:
			self.config['system-theme'] = {
				'color-variants': "",
				'system-theme-name': "",
				'icon-theme-name': "",
				'cursor-theme-name': ""
			}
			with open(CONFIG_FILE, 'w') as f:
				self.config.write(f)
		
	def set_system_theme(self):
		print(self.timestamp)
	
	def __run_daemon(self):
		now = datetime.datetime.now()
		self.timestamp = now.strftime('%Y-%m-%d %H:%M:%S')
		
	# def __quit(self, *args):
	#	 Gtk.main_quit()
		
if __name__ == "__main__":
	print("Nothing")
	ThemeManager()
	ThemeManager.__run_daemon(self=ThemeManager)
	ThemeManager.set_system_theme(self=ThemeManager)